#!/bin/bash

# Exit on error
set -e

echo "🔄 Updating Diablo IV Trade Android app..."

# Check if Android folder exists
if [ ! -d "android" ]; then
  echo "❌ Error: Android project not found. Run setup-mobile.sh first." >&2
  exit 1
fi

# Build the web app
echo "🔨 Building web application..."
npm run build

# Copy web assets to the native project
echo "📋 Copying web assets to Android..."
npx cap copy android

# Sync plugins
echo "🔌 Syncing plugins..."
npx cap sync android

echo "✅ Android app updated successfully!"
echo ""
echo "To open in Android Studio:"
echo "  npx cap open android"
echo ""
echo "To run on a connected device:"
echo "  cd android && ./gradlew installDebug"