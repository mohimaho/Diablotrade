import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Item } from "@shared/schema";
import ItemCard from "@/components/ItemCard";
import Pagination from "@/components/Pagination";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Search, Filter } from "lucide-react";

interface ItemsResponse {
  items: Item[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
  };
}

export default function Browse() {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    type: "",
    rarity: "",
    currency: "",
    search: "",
    sortBy: "newest"
  });

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);

  const { data: itemsData, isLoading, isPending } = useQuery<ItemsResponse>({
    queryKey: ['/api/items', { ...filters, page: currentPage }],
  });

  const { data: rarities } = useQuery<string[]>({
    queryKey: ['/api/enum/rarities'],
  });

  const { data: types } = useQuery<string[]>({
    queryKey: ['/api/enum/types'],
  });

  const handleBuyItem = (item: Item) => {
    toast({
      title: "Coming Soon",
      description: "Item purchasing will be available soon!",
    });
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, search: e.target.value }));
  };

  const handleFilter = (key: string, value: string) => {
    // Convert "all_types" to empty string for backend filtering
    const processedValue = key === "type" && value === "all_types" ? "" : value;
    setFilters(prev => ({ ...prev, [key]: processedValue }));
  };

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-heading text-accent mb-6">Browse Items</h1>

      {/* Search and Filters */}
      <div className="mb-8 p-4 bg-secondary/80 backdrop-blur-md rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search items..."
                className="gothic-input w-full py-2 px-4 pr-10 rounded"
                value={filters.search}
                onChange={handleSearchChange}
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-accent/70 h-4 w-4" />
            </div>
          </div>
          
          <div>
            <Select
              value={filters.type}
              onValueChange={(value) => handleFilter("type", value)}
            >
              <SelectTrigger className="gothic-input w-full">
                <SelectValue placeholder="Item Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_types">All Types</SelectItem>
                {types?.map((type: string) => (
                  <SelectItem key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Select
              value={filters.sortBy}
              onValueChange={(value) => handleFilter("sortBy", value)}
            >
              <SelectTrigger className="gothic-input w-full">
                <SelectValue placeholder="Sort By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="level">Item Level</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="text-accent/80 self-center mr-2">Quick filters:</span>
          
          <Button
            variant={filters.rarity === "legendary" ? "default" : "outline"}
            size="sm"
            className={filters.rarity !== "legendary" ? "bg-[#392b21] hover:bg-[#392b21]/70" : ""}
            onClick={() => handleFilter("rarity", filters.rarity === "legendary" ? "" : "legendary")}
          >
            Legendary
          </Button>
          
          <Button
            variant={filters.rarity === "unique" ? "default" : "outline"}
            size="sm"
            className={filters.rarity !== "unique" ? "bg-[#392b21] hover:bg-[#392b21]/70" : ""}
            onClick={() => handleFilter("rarity", filters.rarity === "unique" ? "" : "unique")}
          >
            Unique
          </Button>
          
          <Button
            variant={filters.rarity === "set" ? "default" : "outline"}
            size="sm"
            className={filters.rarity !== "set" ? "bg-[#392b21] hover:bg-[#392b21]/70" : ""}
            onClick={() => handleFilter("rarity", filters.rarity === "set" ? "" : "set")}
          >
            Set Items
          </Button>
          
          <Button
            variant={filters.currency === "gold" ? "default" : "outline"}
            size="sm"
            className={filters.currency !== "gold" ? "bg-[#392b21] hover:bg-[#392b21]/70" : ""}
            onClick={() => handleFilter("currency", filters.currency === "gold" ? "" : "gold")}
          >
            Gold Only
          </Button>
          
          <Button
            variant={filters.currency === "money" ? "default" : "outline"}
            size="sm"
            className={filters.currency !== "money" ? "bg-[#392b21] hover:bg-[#392b21]/70" : ""}
            onClick={() => handleFilter("currency", filters.currency === "money" ? "" : "money")}
          >
            Real Money
          </Button>
        </div>
      </div>
      
      {/* Item Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-[400px] bg-secondary/50 animate-pulse rounded-lg"></div>
          ))}
        </div>
      ) : itemsData?.items.length === 0 ? (
        <div className="text-center py-20 bg-secondary/50 rounded-lg">
          <Filter className="mx-auto h-16 w-16 text-accent/50 mb-4" />
          <h3 className="text-2xl font-heading text-accent mb-2">No items found</h3>
          <p>Try adjusting your filters or search criteria</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => setFilters({
              type: "",
              rarity: "",
              currency: "",
              search: "",
              sortBy: "newest"
            })}
          >
            Clear Filters
          </Button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {itemsData?.items.map((item: Item) => (
              <ItemCard 
                key={item.id} 
                item={item} 
                onBuy={handleBuyItem}
              />
            ))}
          </div>
          
          {itemsData?.pagination && (
            <Pagination 
              currentPage={currentPage}
              totalPages={itemsData.pagination.totalPages}
              onPageChange={setCurrentPage}
            />
          )}
        </>
      )}
    </main>
  );
}
