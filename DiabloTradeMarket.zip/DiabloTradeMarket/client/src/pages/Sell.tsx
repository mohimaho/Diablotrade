import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { insertItemSchema } from "@shared/schema";
import { useLocation } from "wouter";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ImageUpload } from "@/components/ui/image-upload";
import { Coins, DollarSign, AlertTriangle } from "lucide-react";
import LoginPrompt from "@/components/LoginPrompt";

// Extend the schema with validation
const sellItemSchema = insertItemSchema
  .omit({ sellerId: true })
  .extend({
    name: z.string().min(3, { message: "Name must be at least 3 characters" }),
    description: z.string().min(10, { message: "Description must be at least 10 characters" }),
    level: z.number().min(1, { message: "Level must be at least 1" }).max(100, { message: "Level must be at most 100" }),
    currency: z.enum(["gold", "money"]),
    price: z.number().optional(),
    realMoneyPrice: z.string().optional(),
    // Add validation based on currency type
  })
  .refine(
    (data) => {
      if (data.currency === "gold") {
        return data.price !== undefined && data.price > 0;
      }
      return true;
    },
    {
      message: "Price in gold is required",
      path: ["price"],
    }
  )
  .refine(
    (data) => {
      if (data.currency === "money") {
        return data.realMoneyPrice !== undefined && data.realMoneyPrice.length > 0;
      }
      return true;
    },
    {
      message: "Price in USD is required",
      path: ["realMoneyPrice"],
    }
  );

type SellItemFormValues = z.infer<typeof sellItemSchema>;

export default function Sell() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [selectedImage, setSelectedImage] = useState<File | null>(null);

  const { data: rarities } = useQuery({
    queryKey: ['/api/enum/rarities'],
  });

  const { data: types } = useQuery({
    queryKey: ['/api/enum/types'],
  });

  const form = useForm<SellItemFormValues>({
    resolver: zodResolver(sellItemSchema),
    defaultValues: {
      name: "",
      description: "",
      type: "",
      rarity: "",
      level: 1,
      currency: "gold",
      price: undefined,
      realMoneyPrice: undefined,
      attributes: {},
    },
  });

  const { mutate: createItem, isPending } = useMutation({
    mutationFn: async (values: SellItemFormValues) => {
      const formData = new FormData();
      
      if (selectedImage) {
        formData.append("image", selectedImage);
      }
      
      formData.append("data", JSON.stringify(values));
      
      const response = await fetch("/api/items", {
        method: "POST",
        body: formData,
        credentials: "include"
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create item");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/items'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/items'] });
      
      toast({
        title: "Item Listed",
        description: "Your item has been successfully listed for sale",
      });
      
      // Redirect to inventory page
      navigate("/inventory");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: SellItemFormValues) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "You need to login to sell items",
        variant: "destructive",
      });
      return;
    }
    
    // Transform attributes from UI format to object
    createItem(values);
  };

  const currency = form.watch("currency");

  if (!user) {
    return (
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-heading text-accent mb-6">Sell Items</h1>
        <LoginPrompt />
      </main>
    );
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-heading text-accent mb-6">Sell Your Item</h1>
      
      <div className="bg-secondary/80 backdrop-blur-md p-6 rounded-lg diablo-border mb-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Item Image Upload */}
              <div>
                <FormLabel className="block text-foreground mb-2">Item Image</FormLabel>
                <ImageUpload
                  onChange={setSelectedImage}
                  value={null}
                />
              </div>
              
              {/* Item Details Form */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Item Name</FormLabel>
                      <FormControl>
                        <Input 
                          className="gothic-input" 
                          placeholder="Enter the name of your item" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Item Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="gothic-input">
                            <SelectValue placeholder="Select item type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {types?.map((type: string) => (
                            <SelectItem key={type} value={type}>
                              {type.charAt(0).toUpperCase() + type.slice(1)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="rarity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Item Rarity</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="gothic-input">
                            <SelectValue placeholder="Select rarity" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {rarities?.map((rarity: string) => (
                            <SelectItem key={rarity} value={rarity}>
                              {rarity.charAt(0).toUpperCase() + rarity.slice(1)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="level"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Item Level</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          className="gothic-input" 
                          min={1}
                          max={100}
                          placeholder="Item level (1-100)"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Item Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          className="gothic-input resize-none h-24" 
                          placeholder="Describe your item and its attributes"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Pricing Section */}
            <div className="mt-8">
              <h3 className="text-xl font-heading text-accent mb-4">Set Your Price</h3>
              
              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Type</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex space-x-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem 
                            value="gold" 
                            id="gold"
                            className="text-accent border-accent/70"
                          />
                          <label htmlFor="gold" className="flex items-center cursor-pointer">
                            <Coins className="text-accent mr-1 h-4 w-4" /> In-Game Gold
                          </label>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem 
                            value="money" 
                            id="money"
                            className="text-green-400 border-accent/70"
                          />
                          <label htmlFor="money" className="flex items-center cursor-pointer">
                            <DollarSign className="text-green-400 mr-1 h-4 w-4" /> Real Money
                          </label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Gold Price Input */}
              {currency === "gold" && (
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem className="mt-4">
                      <FormLabel>Price in Gold</FormLabel>
                      <div className="relative">
                        <Coins className="absolute left-3 top-1/2 transform -translate-y-1/2 text-accent/70 h-4 w-4" />
                        <FormControl>
                          <Input 
                            type="number" 
                            className="gothic-input pl-10" 
                            placeholder="Enter price in gold"
                            min={1}
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              {/* Money Price Input */}
              {currency === "money" && (
                <FormField
                  control={form.control}
                  name="realMoneyPrice"
                  render={({ field }) => (
                    <FormItem className="mt-4">
                      <FormLabel>Price in USD</FormLabel>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-green-400 h-4 w-4" />
                        <FormControl>
                          <Input 
                            className="gothic-input pl-10" 
                            placeholder="Enter price in USD"
                            {...field}
                          />
                        </FormControl>
                      </div>
                      <p className="text-xs text-foreground/70 mt-1">
                        5% platform fee will be applied to real money transactions.
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>
            
            {/* Submit Button */}
            <div className="mt-8 text-center">
              <Button
                type="submit"
                size="lg"
                className="font-heading"
                disabled={isPending}
              >
                {isPending ? "Processing..." : "List Item for Sale"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
      
      {/* Selling Guidelines */}
      <div className="bg-[#392b21]/60 p-6 rounded-lg">
        <h3 className="text-xl font-heading text-accent mb-4 flex items-center">
          <AlertTriangle className="mr-2 h-5 w-5" />
          Selling Guidelines
        </h3>
        
        <ul className="list-disc pl-5 space-y-2 text-sm">
          <li>All items must be legitimately obtained within Diablo IV.</li>
          <li>Selling accounts or services is prohibited.</li>
          <li>Real money transactions are subject to a 5% platform fee.</li>
          <li>Items will be listed for 7 days before expiring.</li>
          <li>In-game gold payments are processed through the game's trading system.</li>
          <li>Real money payments are secured through our payment processor.</li>
          <li>Fraudulent listings will result in account suspension.</li>
        </ul>
      </div>
    </main>
  );
}
