import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import LoginPrompt from "@/components/LoginPrompt";
import ConversationsList from "@/components/ConversationsList";
import Chat from "@/components/Chat";
import { MessageSquareIcon } from "lucide-react";

export default function Messages() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(null);
  
  // Check if the URL has a conversation ID query parameter
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const conversationId = params.get("id");
    if (conversationId) {
      setSelectedConversationId(parseInt(conversationId));
    }
  }, []);

  // Update the URL when a conversation is selected
  useEffect(() => {
    if (selectedConversationId) {
      window.history.replaceState(
        null, 
        "", 
        `${window.location.pathname}?id=${selectedConversationId}`
      );
    } else {
      window.history.replaceState(
        null,
        "",
        window.location.pathname
      );
    }
  }, [selectedConversationId]);

  if (!user) {
    return <LoginPrompt />;
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Messages</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left sidebar - conversation list */}
        <div className="md:col-span-1">
          <ConversationsList 
            onSelectConversation={(id) => setSelectedConversationId(id)}
            selectedConversationId={selectedConversationId || undefined}
          />
        </div>
        
        {/* Right side - selected conversation */}
        <div className="md:col-span-2">
          {selectedConversationId ? (
            <Chat conversationId={selectedConversationId} />
          ) : (
            <div className="flex flex-col items-center justify-center h-96 bg-muted/50 rounded-lg border border-dashed">
              <MessageSquareIcon className="h-16 w-16 mb-4 text-muted-foreground" />
              <h3 className="text-xl font-medium mb-2">No Conversation Selected</h3>
              <p className="text-muted-foreground text-center max-w-md">
                Select a conversation from the list to view messages, or browse items to start a new conversation with a seller.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}