import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import LoginPrompt from "@/components/LoginPrompt";
import ItemCard from "@/components/ItemCard";
import Pagination from "@/components/Pagination";
import { Button } from "@/components/ui/button";
import { Item } from "@shared/schema";
import { useState } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  
  const { data: itemsData, isLoading } = useQuery({
    queryKey: ['/api/items', { page: currentPage, pageSize: 4 }],
    keepPreviousData: true,
  });
  
  const handleBuyItem = (item: Item) => {
    toast({
      title: "Coming Soon",
      description: "Item purchasing will be available soon!",
    });
  };
  
  return (
    <main className="container mx-auto px-4 py-8">
      {!user && <LoginPrompt />}
      
      <div className="mb-12">
        <div className="text-center mb-10">
          <h1 className="text-5xl font-heading text-accent mb-4">Diablo IV Trade</h1>
          <p className="text-xl mb-6 max-w-3xl mx-auto">
            The premier marketplace for trading valuable items in Sanctuary
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link href="/browse">Browse Items</Link>
            </Button>
            
            <Button asChild variant="outline" size="lg">
              <Link href="/sell">Sell Items</Link>
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-secondary/80 backdrop-blur-md p-6 rounded-lg diablo-border text-center">
            <h2 className="text-2xl font-heading text-accent mb-3">Buy Rare Items</h2>
            <p className="mb-4">
              Find legendary weapons, unique armor, and powerful accessories 
              to enhance your character's abilities in Sanctuary.
            </p>
            <Button asChild variant="outline">
              <Link href="/browse">View Marketplace</Link>
            </Button>
          </div>
          
          <div className="bg-secondary/80 backdrop-blur-md p-6 rounded-lg diablo-border text-center">
            <h2 className="text-2xl font-heading text-accent mb-3">Sell Your Treasures</h2>
            <p className="mb-4">
              List your valuable finds for gold or real money. 
              Our secure trading platform makes selling easy and safe.
            </p>
            <Button asChild variant="outline">
              <Link href="/sell">Start Selling</Link>
            </Button>
          </div>
        </div>
      </div>
      
      <div className="mb-10">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-heading text-accent">Featured Items</h2>
          <Button asChild variant="outline">
            <Link href="/browse">View All</Link>
          </Button>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-[400px] bg-secondary/50 animate-pulse rounded-lg"></div>
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {itemsData?.items.map((item: Item) => (
                <ItemCard 
                  key={item.id} 
                  item={item} 
                  onBuy={handleBuyItem}
                />
              ))}
            </div>
            
            {itemsData?.pagination && (
              <Pagination 
                currentPage={currentPage}
                totalPages={itemsData.pagination.totalPages}
                onPageChange={setCurrentPage}
              />
            )}
          </>
        )}
      </div>
      
      <div className="bg-secondary/80 backdrop-blur-md p-8 rounded-lg diablo-border mb-10">
        <h2 className="text-3xl font-heading text-accent mb-6 text-center">How It Works</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-heading text-accent">1</span>
            </div>
            <h3 className="text-xl font-heading mb-2">Connect</h3>
            <p>Sign in with your Battle.net account to access the trading platform.</p>
          </div>
          
          <div className="text-center">
            <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-heading text-accent">2</span>
            </div>
            <h3 className="text-xl font-heading mb-2">Browse or List</h3>
            <p>Browse available items or list your own for sale with gold or real money.</p>
          </div>
          
          <div className="text-center">
            <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl font-heading text-accent">3</span>
            </div>
            <h3 className="text-xl font-heading mb-2">Trade</h3>
            <p>Complete secure transactions and receive items directly in your game.</p>
          </div>
        </div>
      </div>
    </main>
  );
}
