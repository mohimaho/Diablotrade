import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Item } from "@shared/schema";
import { Trash2, Edit, Loader2, AlertTriangle, ShoppingCart } from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { useLocation } from "wouter";
import LoginPrompt from "@/components/LoginPrompt";

export default function MyInventory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [itemToDelete, setItemToDelete] = useState<number | null>(null);
  
  const { data: items, isLoading } = useQuery({
    queryKey: ['/api/user/items'],
    enabled: !!user,
  });
  
  const { mutate: deleteItem, isPending: isDeleting } = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/items/${id}`, undefined);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/items'] });
      queryClient.invalidateQueries({ queryKey: ['/api/items'] });
      
      toast({
        title: "Item Deleted",
        description: "Your item has been removed from the marketplace",
      });
      
      setItemToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: "Failed to delete the item",
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteConfirm = () => {
    if (itemToDelete !== null) {
      deleteItem(itemToDelete);
    }
  };
  
  const handleEditItem = (id: number) => {
    // Navigate to edit page (to be implemented)
    toast({
      title: "Coming Soon",
      description: "Editing items will be available soon!",
    });
  };
  
  if (!user) {
    return (
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-heading text-accent mb-6">My Inventory</h1>
        <LoginPrompt />
      </main>
    );
  }
  
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-heading text-accent">My Inventory</h1>
        <Button onClick={() => navigate("/sell")}>Sell New Item</Button>
      </div>
      
      {isLoading ? (
        <div className="text-center py-20">
          <Loader2 className="h-10 w-10 animate-spin mx-auto mb-4 text-accent" />
          <p>Loading your items...</p>
        </div>
      ) : items?.length === 0 ? (
        <div className="text-center py-20 bg-secondary/50 rounded-lg diablo-border">
          <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-accent/50" />
          <h2 className="text-2xl font-heading text-accent mb-2">No items listed</h2>
          <p className="mb-6">You haven't listed any items for sale yet.</p>
          <Button onClick={() => navigate("/sell")}>Sell Your First Item</Button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full bg-secondary/80 backdrop-blur-md rounded-lg diablo-border">
            <thead>
              <tr className="border-b border-accent/30">
                <th className="p-4 text-left font-heading text-accent">Item</th>
                <th className="p-4 text-left font-heading text-accent">Type</th>
                <th className="p-4 text-left font-heading text-accent">Rarity</th>
                <th className="p-4 text-left font-heading text-accent">Level</th>
                <th className="p-4 text-left font-heading text-accent">Price</th>
                <th className="p-4 text-right font-heading text-accent">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items?.map((item: Item) => (
                <tr key={item.id} className="border-b border-[#392b21]">
                  <td className="p-4">
                    <div className="flex items-center">
                      <div className="w-12 h-12 mr-4">
                        {item.image ? (
                          <img 
                            src={item.image} 
                            alt={item.name} 
                            className="w-full h-full object-cover rounded diablo-border"
                          />
                        ) : (
                          <div className="w-full h-full bg-[#392b21] rounded diablo-border" />
                        )}
                      </div>
                      <span className="font-medium">{item.name}</span>
                    </div>
                  </td>
                  <td className="p-4 capitalize">{item.type}</td>
                  <td className="p-4 capitalize">{item.rarity}</td>
                  <td className="p-4">{item.level}</td>
                  <td className="p-4">
                    {item.currency === 'gold'
                      ? `${item.price?.toLocaleString()} Gold`
                      : `$${item.realMoneyPrice}`
                    }
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditItem(item.id)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setItemToDelete(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Item</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to remove "{item.name}" from the marketplace?
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDeleteConfirm} disabled={isDeleting}>
                              {isDeleting && itemToDelete === item.id ? (
                                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              ) : (
                                <Trash2 className="h-4 w-4 mr-2" />
                              )}
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      <div className="mt-8 p-4 bg-[#392b21]/60 rounded-lg flex items-start">
        <AlertTriangle className="text-amber-400 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
        <div>
          <h3 className="font-heading text-accent mb-1">Important Notice</h3>
          <p className="text-sm">
            Items listed for sale remain in your inventory until purchased. 
            Once a buyer initiates a purchase, you'll receive a notification to complete the trade in-game.
            Please ensure your listed items are still available for trade.
          </p>
        </div>
      </div>
    </main>
  );
}
