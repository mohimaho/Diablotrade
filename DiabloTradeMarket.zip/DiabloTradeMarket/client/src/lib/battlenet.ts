import { apiRequest } from "./queryClient";

export async function initiateLogin() {
  try {
    console.log("Starting Battle.net login process...");
    const response = await apiRequest("/api/auth/battlenet", {
      method: "GET"
    });
    console.log("Received response from /api/auth/battlenet:", response.status);
    
    const data = await response.json();
    console.log("Battle.net auth data:", data);
    
    if (data.authUrl) {
      console.log("Redirecting to Battle.net auth URL:", data.authUrl);
      // Redirect to Battle.net auth page
      window.location.href = data.authUrl;
    } else {
      throw new Error("Failed to get Battle.net authentication URL");
    }
  } catch (error) {
    console.error("Battle.net login error:", error);
    throw error;
  }
}

export async function logout() {
  try {
    await apiRequest("/api/auth/logout", {
      method: "POST"
    });
    return true;
  } catch (error) {
    console.error("Logout error:", error);
    throw error;
  }
}
