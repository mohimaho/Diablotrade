import * as React from "react"

const MOBILE_BREAKPOINT = 768

interface MobileState {
  isMobile: boolean;
  isNativeApp: boolean;
  isAndroid: boolean;
  isIOS: boolean;
}

export function useIsMobile(): MobileState {
  const [state, setState] = React.useState<MobileState>({
    isMobile: false,
    isNativeApp: false,
    isAndroid: false,
    isIOS: false
  });

  React.useEffect(() => {
    // Check if device is mobile based on screen size
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      updateState();
    }
    
    // Function to detect if this is a native app environment
    const checkIfNativeApp = () => {
      // Check if running in Capacitor
      const isCapacitor = typeof (window as any).Capacitor !== 'undefined';
      // Check if it's an Android device
      const isAndroid = /android/i.test(navigator.userAgent) || 
                       (isCapacitor && (window as any).Capacitor?.getPlatform() === 'android');
      // Check if it's an iOS device
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
                    (isCapacitor && (window as any).Capacitor?.getPlatform() === 'ios');
      
      return {
        isNativeApp: isCapacitor,
        isAndroid,
        isIOS
      };
    };
    
    const updateState = () => {
      const isMobile = window.innerWidth < MOBILE_BREAKPOINT;
      const { isNativeApp, isAndroid, isIOS } = checkIfNativeApp();
      
      setState({
        isMobile,
        isNativeApp,
        isAndroid,
        isIOS
      });
    };
    
    mql.addEventListener("change", onChange);
    updateState();
    
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return state;
}
