import { createContext, useState, useContext, ReactNode } from "react";
import { queryClient } from "@/lib/queryClient";

export interface User {
  id: number;
  username: string;
  battletag: string;
  avatar?: string;
  gold?: number;
}

interface AuthContextType {
  user: User | null;
  setUser: (user: User | null) => void;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  setUser: () => {}
});

export const AuthProvider = ({ 
  children, 
  initialUser = null 
}: { 
  children: ReactNode;
  initialUser?: User | null;
}): JSX.Element => {
  const [user, setUser] = useState<User | null>(initialUser);

  return (
    <AuthContext.Provider value={{ user, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};