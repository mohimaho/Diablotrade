import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DonationButton() {
  const handleDonateClick = () => {
    window.open('https://liberapay.com/DiabloIVTrade/donate', '_blank');
  };

  return (
    <Button 
      variant="outline" 
      size="sm"
      onClick={handleDonateClick}
      className="flex items-center border-accent/50 hover:bg-accent/20 hover:text-accent"
    >
      <Heart className="h-4 w-4 mr-2 text-accent" />
      <span>Donate</span>
    </Button>
  );
}