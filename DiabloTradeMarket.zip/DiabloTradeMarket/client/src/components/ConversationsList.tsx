import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

interface Conversation {
  id: number;
  itemId: number;
  sellerId: number;
  buyerId: number;
  status: string;
  battletagShared: boolean;
  createdAt: string;
  updatedAt: string;
  unreadCount: number;
  item?: {
    id: number;
    name: string;
    image: string | null;
  };
  buyer?: {
    id: number;
    username: string;
    battletag?: string;
    avatar?: string;
  };
  seller?: {
    id: number;
    username: string;
    battletag?: string;
    avatar?: string;
  };
}

interface ConversationsListProps {
  onSelectConversation?: (conversationId: number) => void;
  selectedConversationId?: number;
}

export default function ConversationsList({ 
  onSelectConversation,
  selectedConversationId 
}: ConversationsListProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchConversations = async () => {
      try {
        setLoading(true);
        const response = await apiRequest("/api/conversations", {
          method: "GET"
        });
        if (response.ok) {
          const data = await response.json();
          setConversations(data);
        } else {
          toast({
            title: "Error",
            description: "Failed to load conversations",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Error fetching conversations:", error);
        toast({
          title: "Error",
          description: "Failed to load conversations",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchConversations();
  }, [toast]);

  if (loading) {
    return <div className="p-4">Loading conversations...</div>;
  }

  if (conversations.length === 0) {
    return (
      <div className="p-4 text-center">
        <p className="text-muted-foreground mb-4">You don't have any active conversations</p>
        <Button asChild>
          <Link href="/browse">Browse Items</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {conversations.map((conversation) => {
        const otherUser = user?.id === conversation.sellerId ? conversation.buyer : conversation.seller;
        const isSelected = selectedConversationId === conversation.id;
        
        return (
          <Card 
            key={conversation.id} 
            className={`cursor-pointer hover:bg-accent/50 transition-colors ${isSelected ? 'bg-accent' : ''}`}
            onClick={() => onSelectConversation?.(conversation.id)}
          >
            <CardHeader className="p-4 pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage
                      src={otherUser?.avatar || ""}
                      alt={otherUser?.username || "User"}
                    />
                    <AvatarFallback>
                      {(otherUser?.username || "U").charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-sm font-medium">{otherUser?.username}</h4>
                    {conversation.battletagShared && otherUser?.battletag && (
                      <p className="text-xs text-muted-foreground">{otherUser.battletag}</p>
                    )}
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(conversation.updatedAt), { addSuffix: true })}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4 py-2">
              <div className="flex items-center space-x-3">
                {conversation.item?.image ? (
                  <img 
                    src={conversation.item.image} 
                    alt={conversation.item?.name} 
                    className="w-10 h-10 object-cover rounded-md"
                  />
                ) : (
                  <div className="w-10 h-10 bg-muted rounded-md flex items-center justify-center">
                    <span className="text-xs">No Image</span>
                  </div>
                )}
                <div className="text-sm">{conversation.item?.name}</div>
              </div>
            </CardContent>
            {conversation.unreadCount > 0 && (
              <CardFooter className="p-4 pt-0">
                <Badge variant="secondary" className="ml-auto">
                  {conversation.unreadCount} new {conversation.unreadCount === 1 ? 'message' : 'messages'}
                </Badge>
              </CardFooter>
            )}
          </Card>
        );
      })}
    </div>
  );
}