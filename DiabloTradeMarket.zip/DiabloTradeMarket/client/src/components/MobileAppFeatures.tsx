import { useEffect, useState } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useToast } from '@/hooks/use-toast';

// Define interface for any global Capacitor instance
interface CapacitorGlobal {
  Plugins?: {
    App?: {
      addListener: (eventName: string, callback: Function) => any;
      exitApp: () => void;
    }
  };
  isNativePlatform?: () => boolean;
}

/**
 * Component that adds mobile app-specific features when running in Capacitor
 */
export default function MobileAppFeatures() {
  const { isNativeApp, isAndroid, isIOS } = useIsMobile();
  const { toast } = useToast();
  const [initAttempted, setInitAttempted] = useState(false);
  
  useEffect(() => {
    if (isNativeApp && !initAttempted) {
      setInitAttempted(true);
      
      // Handle specific mobile app behaviors
      const setupMobileApp = async () => {
        try {
          // Safely check if we're in a Capacitor native app
          const capacitor = (window as any).Capacitor as CapacitorGlobal | undefined;
          
          if (capacitor?.Plugins?.App) {
            const appPlugin = capacitor.Plugins.App;
            
            if (isAndroid) {
              // Setup back button handler for Android
              appPlugin.addListener('backButton', (data: any) => {
                // Check if we can go back in history
                const canGoBack = window.history.length > 1;
                
                if (canGoBack) {
                  window.history.back();
                } else {
                  // Show a prompt to confirm exit
                  if (confirm('Are you sure you want to exit the app?')) {
                    appPlugin.exitApp();
                  }
                }
              });
            }
            
            // Handle app state changes for both Android and iOS
            appPlugin.addListener('appStateChange', (data: any) => {
              const isActive = data?.isActive;
              if (isActive) {
                // App has come to the foreground
                console.log('App is active');
              } else {
                // App has gone to the background
                console.log('App is inactive');
              }
            });
            
            // Show a welcome toast for the native app
            toast({
              title: "Native App Detected",
              description: `Running on ${isAndroid ? 'Android' : 'iOS'} device`,
              duration: 3000,
            });
          }
        } catch (error) {
          console.error('Error setting up mobile features:', error);
        }
      };
      
      setupMobileApp();
    }
  }, [isNativeApp, isAndroid, isIOS, toast, initAttempted]);
  
  // This component doesn't render anything visible
  return null;
}