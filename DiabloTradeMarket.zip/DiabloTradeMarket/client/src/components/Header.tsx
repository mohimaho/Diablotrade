import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { GamepadIcon, User, LogOut, Menu, ChevronDown, Coins, MessageSquare } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { initiateLogin, logout } from "@/lib/battlenet";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import DonationButton from "./DonationButton";

export default function Header() {
  const [location, navigate] = useLocation();
  const { user, setUser } = useAuth();
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleBattleNetLogin = async () => {
    try {
      await initiateLogin();
    } catch (error) {
      toast({
        title: "Login Error",
        description: "Failed to connect to Battle.net",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
      toast({
        title: "Logged out",
        description: "You've been successfully logged out",
      });
    } catch (error) {
      toast({
        title: "Logout Error",
        description: "Failed to log out",
        variant: "destructive",
      });
    }
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-background/90 backdrop-blur-md sticky top-0 z-50 border-b border-accent/30">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-heading font-bold text-accent flex items-center">
            <img src="/images/logo.jpeg" alt="Diablo IV Trade Logo" className="h-8 w-8 mr-2 rounded" />
            Diablo IV Trade
          </Link>
        </div>
        
        <div className="hidden md:flex space-x-6 items-center">
          <Link 
            href="/browse" 
            className={`hover:text-accent transition-colors ${location === '/browse' ? 'text-accent' : 'text-foreground'}`}
          >
            Browse
          </Link>
          <Link 
            href="/sell" 
            className={`hover:text-accent transition-colors ${location === '/sell' ? 'text-accent' : 'text-foreground'}`}
          >
            Sell
          </Link>
          {user && (
            <>
              <Link 
                href="/inventory" 
                className={`hover:text-accent transition-colors ${location === '/inventory' ? 'text-accent' : 'text-foreground'}`}
              >
                My Inventory
              </Link>
              <Link 
                href="/messages" 
                className={`hover:text-accent transition-colors flex items-center ${location === '/messages' ? 'text-accent' : 'text-foreground'}`}
              >
                <MessageSquare className="mr-1 h-4 w-4" />
                Messages
              </Link>
            </>
          )}
          <div className="ml-2">
            <DonationButton />
          </div>
        </div>
        
        {!user ? (
          <Button 
            className="flex items-center"
            onClick={handleBattleNetLogin}
          >
            <GamepadIcon className="mr-2 h-4 w-4" />
            Battle.net Login
          </Button>
        ) : (
          <div className="flex items-center space-x-4">
            <div className="flex items-center bg-[#392b21]/60 px-3 py-1 rounded">
              <Coins className="text-accent mr-2 h-4 w-4" />
              <span>{user.gold?.toLocaleString()}</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto hover:bg-transparent">
                  <div className="flex items-center">
                    {user.avatar ? (
                      <img 
                        src={user.avatar} 
                        alt={user.battletag} 
                        className="h-8 w-8 rounded-full diablo-border"
                      />
                    ) : (
                      <div className="h-8 w-8 rounded-full diablo-border bg-secondary flex items-center justify-center">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                    <span className="ml-2 hidden sm:inline">{user.battletag}</span>
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/inventory" className="w-full cursor-pointer">
                    My Listings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/messages" className="w-full cursor-pointer flex items-center">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Messages
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
        
        <Button
          variant="ghost"
          className="md:hidden"
          onClick={toggleMobileMenu}
        >
          <Menu className="h-6 w-6" />
        </Button>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-secondary/95 backdrop-blur-md">
          <div className="container mx-auto px-4 py-2 flex flex-col space-y-3">
            <Link 
              href="/browse"
              className={`hover:text-accent py-2 border-b border-[#392b21] ${location === '/browse' ? 'text-accent' : 'text-foreground'}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Browse
            </Link>
            <Link 
              href="/sell"
              className={`hover:text-accent py-2 border-b border-[#392b21] ${location === '/sell' ? 'text-accent' : 'text-foreground'}`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Sell
            </Link>
            {user && (
              <>
                <Link 
                  href="/inventory"
                  className={`hover:text-accent py-2 border-b border-[#392b21] ${location === '/inventory' ? 'text-accent' : 'text-foreground'}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  My Inventory
                </Link>
                <Link 
                  href="/messages"
                  className={`hover:text-accent py-2 border-b border-[#392b21] flex items-center ${location === '/messages' ? 'text-accent' : 'text-foreground'}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Messages
                </Link>
              </>
            )}
            <div className="py-3 flex justify-center">
              <DonationButton />
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
