import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { SendIcon, Share2Icon } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

interface ChatMessage {
  id: number;
  conversationId: number;
  senderId: number;
  content: string;
  createdAt: string;
  readAt: string | null;
  sender?: {
    id: number;
    username: string;
    avatar?: string;
  };
}

interface Conversation {
  id: number;
  itemId: number;
  sellerId: number;
  buyerId: number;
  status: string;
  battletagShared: boolean;
  createdAt: string;
  updatedAt: string;
  item?: {
    id: number;
    name: string;
    image: string | null;
  };
  buyer?: {
    id: number;
    username: string;
    battletag?: string;
    avatar?: string;
  };
  seller?: {
    id: number;
    username: string;
    battletag?: string;
    avatar?: string;
  };
  messages?: ChatMessage[];
}

interface ChatProps {
  conversationId: number;
}

export default function Chat({ conversationId }: ChatProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messageText, setMessageText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [sharing, setSharing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const ws = useRef<WebSocket | null>(null);

  // Fetch conversation data
  useEffect(() => {
    const fetchConversation = async () => {
      try {
        setLoading(true);
        const response = await apiRequest(`/api/conversations/${conversationId}`, {
          method: "GET"
        });
        if (response.ok) {
          const data = await response.json();
          setConversation(data);
          setMessages(data.messages || []);
        } else {
          toast({
            title: "Error",
            description: "Failed to load conversation",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Error fetching conversation:", error);
        toast({
          title: "Error",
          description: "Failed to load conversation",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchConversation();
  }, [conversationId, toast]);

  // Set up WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);
    
    ws.current.onopen = () => {
      console.log("WebSocket connected");
      // Join the conversation room
      if (ws.current && ws.current.readyState === WebSocket.OPEN) {
        ws.current.send(JSON.stringify({
          type: "join_conversation",
          conversationId,
        }));
      }
    };
    
    ws.current.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "new_message" && data.message) {
          // Add new message to the list
          setMessages((prev) => [...prev, data.message]);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };
    
    ws.current.onerror = (error) => {
      console.error("WebSocket error:", error);
    };
    
    ws.current.onclose = () => {
      console.log("WebSocket disconnected");
    };
    
    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, [conversationId]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!messageText.trim() || sending) return;
    
    try {
      setSending(true);
      const response = await apiRequest(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: messageText.trim(),
        }),
      });
      
      if (response.ok) {
        setMessageText("");
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.message || "Failed to send message",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  const shareBattletag = async () => {
    if (sharing) return;
    
    try {
      setSharing(true);
      const response = await apiRequest(`/api/conversations/${conversationId}/share-battletag`, {
        method: "POST",
      });
      
      if (response.ok) {
        const data = await response.json();
        setConversation((prev) => prev ? { ...prev, battletagShared: true } : null);
        toast({
          title: "Battletag Shared",
          description: "Your battletag has been shared with the other user",
        });
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.message || "Failed to share battletag",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error sharing battletag:", error);
      toast({
        title: "Error",
        description: "Failed to share battletag",
        variant: "destructive",
      });
    } finally {
      setSharing(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading conversation...</div>;
  }

  if (!conversation) {
    return <div className="flex items-center justify-center h-64">Conversation not found</div>;
  }

  const otherUser = user?.id === conversation.sellerId ? conversation.buyer : conversation.seller;

  return (
    <div className="flex flex-col h-full bg-background rounded-lg border">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-3">
          {conversation.item?.image ? (
            <img 
              src={conversation.item.image} 
              alt={conversation.item?.name} 
              className="w-12 h-12 object-cover rounded-md"
            />
          ) : (
            <div className="w-12 h-12 bg-muted rounded-md flex items-center justify-center">
              <span className="text-xs">No Image</span>
            </div>
          )}
          <div className="flex-1">
            <h3 className="font-bold">{conversation.item?.name || "Item"}</h3>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                Chatting with {otherUser?.username}
              </span>
              {conversation.battletagShared && otherUser?.battletag && (
                <Badge variant="secondary">{otherUser.battletag}</Badge>
              )}
            </div>
          </div>
          {!conversation.battletagShared && (
            <Button 
              onClick={shareBattletag} 
              disabled={sharing}
              size="sm"
              variant="outline"
            >
              <Share2Icon className="h-4 w-4 mr-2" />
              Share Battletag
            </Button>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            No messages yet. Start the conversation!
          </div>
        ) : (
          messages.map((message) => {
            const isCurrentUser = message.senderId === user?.id;
            return (
              <div 
                key={message.id} 
                className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex gap-2 max-w-[80%] ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                  <Avatar className="h-8 w-8">
                    <AvatarImage
                      src={message.sender?.avatar || ""}
                      alt={message.sender?.username || "User"}
                    />
                    <AvatarFallback>
                      {(message.sender?.username || "U").charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`rounded-lg p-3 ${isCurrentUser ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                    <div className="text-sm">{message.content}</div>
                    <div className="text-xs mt-1 opacity-70">
                      {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Input
            placeholder="Type your message..."
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            disabled={sending}
            className="flex-1"
          />
          <Button onClick={sendMessage} disabled={sending || !messageText.trim()}>
            <SendIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}