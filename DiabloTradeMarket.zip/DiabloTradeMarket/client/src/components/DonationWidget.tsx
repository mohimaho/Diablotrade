import { useEffect, useRef } from "react";

export default function DonationWidget() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Create the script element
    const script = document.createElement('script');
    script.src = "https://liberapay.com/DiabloIVTrade/widgets/button.js";
    script.async = true;
    
    // Append the script to the container
    if (containerRef.current) {
      containerRef.current.appendChild(script);
    }
    
    // Cleanup function to remove the script when component unmounts
    return () => {
      if (containerRef.current && script.parentNode) {
        containerRef.current.removeChild(script);
      }
    };
  }, []);
  
  return (
    <div className="donation-widget">
      <div ref={containerRef}>
        {/* Script will be inserted here */}
      </div>
      <noscript>
        <a href="https://liberapay.com/DiabloIVTrade/donate">
          <img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg" />
        </a>
      </noscript>
    </div>
  );
}