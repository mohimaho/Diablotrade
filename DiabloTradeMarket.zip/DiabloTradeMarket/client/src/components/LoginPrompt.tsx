import { Button } from "@/components/ui/button";
import { GamepadIcon } from "lucide-react";
import { initiateLogin } from "@/lib/battlenet";
import { useToast } from "@/hooks/use-toast";
import { SiBattledotnet } from "react-icons/si";

export default function LoginPrompt() {
  const { toast } = useToast();

  const handleBattleNetLogin = async () => {
    try {
      await initiateLogin();
    } catch (error: any) {
      console.error("Login error:", error);
      toast({
        title: "Login Error",
        description: error?.message || "Failed to connect to Battle.net",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="mb-8 bg-secondary/80 backdrop-blur-md p-6 rounded-lg diablo-border">
      <div className="text-center">
        <h2 className="text-3xl font-heading mb-4 text-accent">Welcome, Wanderer</h2>
        <p className="mb-6 max-w-2xl mx-auto">
          Connect with your Battle.net account to start trading the most powerful items in Sanctuary. 
          Buy rare equipment from other players or sell your legendary discoveries.
        </p>
        <Button
          size="lg"
          className="mx-auto"
          onClick={handleBattleNetLogin}
        >
          <SiBattledotnet className="mr-2 h-5 w-5" />
          Login with Battle.net
        </Button>
      </div>
    </div>
  );
}
