import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Camera, Trash2, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface ImageUploadProps {
  onChange: (file: File | null) => void;
  value?: string | null;
  className?: string;
}

export function ImageUpload({ onChange, value, className }: ImageUploadProps) {
  const [preview, setPreview] = useState<string | null>(value || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    onChange(file);
    
    const reader = new FileReader();
    reader.onload = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemove = () => {
    setPreview(null);
    onChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={cn("w-full", className)}>
      {!preview ? (
        <div 
          className="border-2 border-dashed border-[#392b21] hover:border-accent/50 rounded-lg p-4 text-center cursor-pointer transition-colors"
          onClick={triggerFileInput}
        >
          <div className="py-8">
            <Camera className="h-12 w-12 mx-auto mb-4 text-accent/70" />
            <p className="mb-2">Take a screenshot or upload an image</p>
            <p className="text-xs text-foreground/70">PNG, JPG or GIF, max 5MB</p>
          </div>
          <input 
            type="file" 
            ref={fileInputRef}
            className="hidden" 
            accept="image/*"
            onChange={handleFileChange}
          />
        </div>
      ) : (
        <div className="mt-4">
          <div className="relative">
            <img 
              src={preview} 
              alt="Item preview" 
              className="max-h-60 w-full object-cover rounded"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={handleRemove}
              >
                <Trash2 className="h-4 w-4 mr-1" /> Remove
              </Button>
              <Button 
                variant="secondary" 
                size="sm" 
                onClick={triggerFileInput}
              >
                <Upload className="h-4 w-4 mr-1" /> Change
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
