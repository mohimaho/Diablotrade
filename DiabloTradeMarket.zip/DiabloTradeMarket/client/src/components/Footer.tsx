import { Link } from "wouter";
import DonationWidget from "./DonationWidget";

export default function Footer() {
  return (
    <footer className="bg-background/90 backdrop-blur-md border-t border-accent/30 mt-10">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-heading text-accent mb-4">Diablo IV Trade</h3>
            <p className="text-sm text-foreground/80">The premier marketplace for Diablo IV items. Buy and sell with confidence in our secure trading environment.</p>
            
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Support This Project</h4>
              <DonationWidget />
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-heading text-accent mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-foreground/80 hover:text-accent transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/browse" className="text-foreground/80 hover:text-accent transition-colors">
                  Browse Items
                </Link>
              </li>
              <li>
                <Link href="/sell" className="text-foreground/80 hover:text-accent transition-colors">
                  Sell Items
                </Link>
              </li>
              <li>
                <Link href="/inventory" className="text-foreground/80 hover:text-accent transition-colors">
                  My Inventory
                </Link>
              </li>
              <li>
                <Link href="/messages" className="text-foreground/80 hover:text-accent transition-colors">
                  Messages
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-heading text-accent mb-4">Support</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  Safety Tips
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-heading text-accent mb-4">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  User Agreement
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/80 hover:text-accent transition-colors">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-[#392b21] text-center text-xs text-foreground/60">
          <p>Diablo IV Trade is not affiliated with or endorsed by Blizzard Entertainment, Inc.</p>
          <p className="mt-2">Diablo and Battle.net are trademarks or registered trademarks of Blizzard Entertainment, Inc.</p>
          <p className="mt-4">&copy; {new Date().getFullYear()} Diablo IV Trade. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
