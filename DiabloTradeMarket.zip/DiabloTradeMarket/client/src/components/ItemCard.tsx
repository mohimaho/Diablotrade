import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Item } from "@shared/schema";
import { Coins, DollarSign } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

interface ItemCardProps {
  item: Item;
  onBuy?: (item: Item) => void;
}

export default function ItemCard({ item, onBuy }: ItemCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const handleBuy = () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "You need to login to buy items",
        variant: "destructive",
      });
      return;
    }
    
    if (onBuy) {
      onBuy(item);
    }
  };
  
  // Helper to format the rarity badge
  const getRarityBadge = (rarity: string) => {
    return (
      <span className="bg-primary/90 text-foreground text-xs px-2 py-1 rounded">
        {rarity.charAt(0).toUpperCase() + rarity.slice(1)}
      </span>
    );
  };
  
  // Helper to format the currency badge
  const getCurrencyBadge = (currency: string, price?: number | null, realMoneyPrice?: string | null) => {
    if (currency === "gold" && price) {
      return (
        <span className="bg-accent/90 text-background text-xs px-2 py-1 rounded flex items-center">
          <Coins className="mr-1 h-3 w-3" /> Gold
        </span>
      );
    } else if (currency === "money" && realMoneyPrice) {
      return (
        <span className="bg-green-500/90 text-foreground text-xs px-2 py-1 rounded flex items-center">
          <DollarSign className="mr-1 h-3 w-3" /> {realMoneyPrice}
        </span>
      );
    }
    return null;
  };
  
  // Format item attributes for display
  const getAttributes = () => {
    if (!item.attributes) return [];
    
    return Object.entries(item.attributes).map(([key, value]) => ({
      name: key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()),
      value
    }));
  };

  return (
    <Card className="item-card bg-secondary/80 backdrop-blur-md rounded-lg overflow-hidden diablo-border">
      <div className="relative">
        <img 
          src={item.image || "https://images.unsplash.com/photo-1501884428012-aa321aaf9ce6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"} 
          alt={item.name} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 flex space-x-1">
          {getRarityBadge(item.rarity)}
        </div>
        <div className="absolute bottom-2 left-2">
          {getCurrencyBadge(item.currency, item.price, item.realMoneyPrice)}
        </div>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-heading text-accent text-lg mb-1">{item.name}</h3>
        <p className="text-sm mb-2">{item.type} | Level {item.level}</p>
        
        <div className="mb-3 text-xs">
          {getAttributes().slice(0, 3).map((attr, idx) => (
            <div key={idx} className="flex justify-between mb-1">
              <span>{attr.name}</span>
              <span className="text-accent">{attr.value}</span>
            </div>
          ))}
        </div>
        
        <div className="flex items-center justify-between">
          {item.currency === "gold" ? (
            <div className="text-xl font-bold flex items-center text-accent">
              <Coins className="mr-1 h-4 w-4" /> {item.price?.toLocaleString()}
            </div>
          ) : (
            <div className="text-xl font-bold flex items-center text-green-400">
              <DollarSign className="mr-1 h-4 w-4" /> {item.realMoneyPrice}
            </div>
          )}
          
          <Button 
            size="sm"
            onClick={handleBuy}
          >
            Buy Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
