import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { useQuery } from "@tanstack/react-query";
import { User, AuthContext } from "@/hooks/use-auth";
import { useState, ReactNode } from "react";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Browse from "@/pages/Browse";
import Sell from "@/pages/Sell";
import MyInventory from "@/pages/MyInventory";
import Messages from "@/pages/Messages";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import MobileAppFeatures from "@/components/MobileAppFeatures";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/browse" component={Browse} />
      <Route path="/sell" component={Sell} />
      <Route path="/inventory" component={MyInventory} />
      <Route path="/messages" component={Messages} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Fix for TypeScript error with AuthProvider component
function CustomAuthProvider({ children, initialUser }: { children: ReactNode; initialUser: User | null }) {
  const [user, setUser] = useState<User | null>(initialUser);
  
  return (
    <AuthContext.Provider value={{ user, setUser }}>
      {children}
    </AuthContext.Provider>
  );
}

function App() {
  // Fetch current auth state on app load
  const { data: currentUser } = useQuery<User | null>({
    queryKey: ['/api/auth/user'],
    retry: false,
    staleTime: Infinity,
  });

  // Create auth context with user state
  return (
    <CustomAuthProvider initialUser={currentUser || null}>
      <div className="min-h-screen flex flex-col text-foreground">
        <Header />
        <div className="flex-grow">
          <Router />
        </div>
        <Footer />
      </div>
      <MobileAppFeatures />
      <Toaster />
    </CustomAuthProvider>
  );
}

export default App;
