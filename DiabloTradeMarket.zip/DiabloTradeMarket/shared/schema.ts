import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  battletag: text("battletag").notNull(),
  battlenetId: text("battlenet_id").notNull().unique(),
  avatar: text("avatar"),
  gold: integer("gold").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  battletag: true,
  battlenetId: true,
  avatar: true,
  gold: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  rarity: text("rarity").notNull(),
  level: integer("level").notNull(),
  image: text("image"),
  attributes: json("attributes").$type<Record<string, string>>(),
  price: integer("price"),
  realMoneyPrice: text("real_money_price"),
  currency: text("currency").notNull().default("gold"),
  sellerId: integer("seller_id").notNull(),
  sold: boolean("sold").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  readAt: timestamp("read_at"),
});

// Chat conversations table
export const chatConversations = pgTable("chat_conversations", {
  id: serial("id").primaryKey(),
  itemId: integer("item_id").notNull().references(() => items.id),
  buyerId: integer("buyer_id").notNull().references(() => users.id),
  sellerId: integer("seller_id").notNull().references(() => users.id),
  status: text("status", { enum: ["active", "closed", "completed"] }).notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  battletagShared: boolean("battletag_shared").default(false).notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  items: many(items),
  sentMessages: many(chatMessages, { relationName: "senderMessages" }),
  buyerConversations: many(chatConversations, { relationName: "buyerConversations" }),
  sellerConversations: many(chatConversations, { relationName: "sellerConversations" }),
}));

export const itemsRelations = relations(items, ({ one, many }) => ({
  seller: one(users, {
    fields: [items.sellerId],
    references: [users.id],
  }),
  conversations: many(chatConversations),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  sender: one(users, {
    fields: [chatMessages.senderId],
    references: [users.id],
    relationName: "senderMessages",
  }),
  conversation: one(chatConversations, {
    fields: [chatMessages.conversationId],
    references: [chatConversations.id],
  }),
}));

export const chatConversationsRelations = relations(chatConversations, ({ one, many }) => ({
  buyer: one(users, {
    fields: [chatConversations.buyerId],
    references: [users.id],
    relationName: "buyerConversations",
  }),
  seller: one(users, {
    fields: [chatConversations.sellerId],
    references: [users.id],
    relationName: "sellerConversations",
  }),
  item: one(items, {
    fields: [chatConversations.itemId],
    references: [items.id],
  }),
  messages: many(chatMessages),
}));

export const insertItemSchema = createInsertSchema(items).pick({
  name: true,
  description: true,
  type: true,
  rarity: true,
  level: true,
  image: true,
  attributes: true,
  price: true,
  realMoneyPrice: true,
  currency: true,
  sellerId: true,
});

export const itemRarityEnum = z.enum([
  "common", 
  "magic", 
  "rare", 
  "legendary", 
  "unique", 
  "set"
]);

export const itemTypeEnum = z.enum([
  "weapon", 
  "armor", 
  "jewelry", 
  "consumable", 
  "material"
]);

export const currencyEnum = z.enum([
  "gold", 
  "money"
]);

// Insert schemas for chat
export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  conversationId: true,
  senderId: true,
  content: true,
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).pick({
  itemId: true,
  buyerId: true,
  sellerId: true,
  status: true,
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof items.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type ChatConversation = typeof chatConversations.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;
