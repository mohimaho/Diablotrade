# Diablo IV Trade - Android App Guide

This guide will help you build, test, and deploy the Diablo IV Trade app on Android devices.

## Prerequisites

Before you begin, make sure you have the following installed on your development machine:

1. [Android Studio](https://developer.android.com/studio)
2. [Java Development Kit (JDK)](https://www.oracle.com/java/technologies/downloads/)
3. [Android SDK](https://developer.android.com/about/versions/12/setup-sdk) (Usually comes with Android Studio)

## Setting Up the Android Project

1. Clone this repository to your local machine
2. Run the setup script to create the Android project:

```bash
./setup-mobile.sh
```

This script will:
- Build the web application
- Initialize Capacitor
- Add the Android platform
- Configure basic Android settings
- Sync the web code to the native project

## Opening the Project in Android Studio

After running the setup script, you can open the Android project in Android Studio:

```bash
npx cap open android
```

This will open Android Studio with the generated Android project.

## Testing on a Physical Device

To test on a physical Android device:

1. Connect your Android device to your computer via USB
2. Enable USB debugging on your device
3. In Android Studio, click the "Run" button (green play icon)
4. Select your device from the list of available devices

## Testing on an Emulator

To test on an Android emulator:

1. In Android Studio, open the AVD Manager (Tools > AVD Manager)
2. Create a new virtual device if you don't have one
3. Start the emulator
4. Click the "Run" button in Android Studio

## Updating the App After Changes

After making changes to the web application, you need to update the Android app:

1. Run the update script:

```bash
./update-android.sh
```

2. Open Android Studio and run the app again to see your changes.

## Building an APK for Distribution

To build an APK that you can share with others:

1. In Android Studio, select Build > Build Bundle(s) / APK(s) > Build APK(s)
2. Wait for the build to complete
3. Click "locate" to find the APK file
4. Share this APK file with your testers

## Preparing for Google Play Store Submission

To submit your app to the Google Play Store:

1. Create a signed release APK or App Bundle:
   - In Android Studio, select Build > Generate Signed Bundle / APK
   - Follow the steps to create a signing key
   - Select "Android App Bundle" or "APK" as the build type
   - Select "release" as the build variant

2. Create a Google Play Developer account:
   - Visit [Google Play Console](https://play.google.com/console)
   - Pay the one-time registration fee ($25)

3. Create your app listing:
   - Fill in app details, descriptions, screenshots
   - Upload your signed APK or App Bundle
   - Set pricing and countries
   - Complete the content rating questionnaire
   - Set up your privacy policy

4. Submit for review:
   - After completing all required information, submit your app for review

## Troubleshooting

Common issues and solutions:

- **App crashes on startup**: Make sure Capacitor has synced properly with `npx cap sync`
- **Network errors**: Check that your Android manifest has proper permissions
- **Black screen**: Verify that the web app is building correctly with `npm run build`

## Additional Resources

- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Android Developer Documentation](https://developer.android.com/docs)
- [Google Play Console Help](https://support.google.com/googleplay/android-developer/)