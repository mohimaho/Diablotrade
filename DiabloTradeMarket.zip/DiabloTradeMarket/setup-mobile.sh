#!/bin/bash

# Exit on error
set -e

echo "🚀 Setting up Diablo IV Trade for mobile..."

# Check for Node.js and npm
if ! [ -x "$(command -v npm)" ]; then
  echo "❌ Error: npm is not installed." >&2
  exit 1
fi

# Install Capacitor CLI globally if not installed
echo "📦 Installing Capacitor CLI..."
npm install -g @capacitor/cli

# Install Capacitor Core and Android platform
echo "📦 Installing Capacitor dependencies..."
npm install @capacitor/core @capacitor/android

# Build the web app
echo "🔨 Building web application..."
npm run build

# Initialize Capacitor
echo "🔧 Initializing Capacitor..."
npx cap init "Diablo IV Trade" "com.diabloivtrade.app" --web-dir "dist"

# Add Android platform
echo "📱 Adding Android platform..."
npx cap add android

# Copy web assets to the native project
echo "📋 Copying web assets to Android..."
npx cap copy android

# Open the Android project in Android Studio
echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Open the Android project in Android Studio: npx cap open android"
echo "2. Make any necessary Android-specific configurations"
echo "3. Run the app on a device or emulator"
echo ""
echo "When you make changes to the web app, run:"
echo "- npm run build"
echo "- npx cap copy android"
echo ""
echo "Or use the update-android.sh script which combines these steps."