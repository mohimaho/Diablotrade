import { User } from '@shared/schema';

// Extend express-session with custom properties
declare module 'express-session' {
  interface SessionData {
    user?: {
      id: number;
      username: string;
      battletag: string;
      avatar?: string;
      gold?: number;
    };
  }
}