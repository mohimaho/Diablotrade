import { 
  users, type User, type InsertUser, 
  items, type Item, type InsertItem,
  chatMessages, chatConversations,
  type ChatMessage, type ChatConversation, 
  type InsertChatMessage, type InsertChatConversation 
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ne, isNull, desc, asc, like, gte, lte, sql, count, inArray } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByBattlenetId(battlenetId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  
  createItem(item: InsertItem): Promise<Item>;
  getItem(id: number): Promise<Item | undefined>;
  getAllItems(filters?: {
    type?: string;
    rarity?: string;
    minLevel?: number;
    maxLevel?: number;
    currency?: string;
    search?: string;
    sortBy?: string;
    page?: number;
    pageSize?: number;
  }): Promise<{ items: Item[], total: number }>;
  getUserItems(userId: number): Promise<Item[]>;
  updateItem(id: number, item: Partial<Item>): Promise<Item | undefined>;
  deleteItem(id: number): Promise<boolean>;
  
  // Chat methods
  createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation>;
  getChatConversation(id: number): Promise<ChatConversation | undefined>;
  getUserConversations(userId: number): Promise<ChatConversation[]>; 
  getChatMessages(conversationId: number): Promise<ChatMessage[]>;
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  markConversationMessagesAsRead(conversationId: number, userId: number): Promise<void>;
  updateChatConversation(id: number, data: Partial<ChatConversation>): Promise<ChatConversation | undefined>;
  getItemConversation(itemId: number, buyerId: number): Promise<ChatConversation | undefined>;
  shareBattletag(conversationId: number): Promise<ChatConversation>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private items: Map<number, Item>;
  private userIdCounter: number;
  private itemIdCounter: number;

  constructor() {
    this.users = new Map();
    this.items = new Map();
    this.userIdCounter = 1;
    this.itemIdCounter = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByBattlenetId(battlenetId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.battlenetId === battlenetId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;
    
    const updatedUser = { ...existingUser, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createItem(insertItem: InsertItem): Promise<Item> {
    const id = this.itemIdCounter++;
    const currentDate = new Date();
    
    const item: Item = {
      ...insertItem,
      id,
      createdAt: currentDate
    };
    
    this.items.set(id, item);
    return item;
  }

  async getItem(id: number): Promise<Item | undefined> {
    return this.items.get(id);
  }

  async getAllItems(filters: {
    type?: string;
    rarity?: string;
    minLevel?: number;
    maxLevel?: number;
    currency?: string;
    search?: string;
    sortBy?: string;
    page?: number;
    pageSize?: number;
  } = {}): Promise<{ items: Item[], total: number }> {
    const {
      type,
      rarity,
      minLevel,
      maxLevel,
      currency,
      search,
      sortBy = "newest",
      page = 1,
      pageSize = 12
    } = filters;

    let filteredItems = Array.from(this.items.values());

    // Apply filters
    if (type) {
      filteredItems = filteredItems.filter(item => item.type === type);
    }
    
    if (rarity) {
      filteredItems = filteredItems.filter(item => item.rarity === rarity);
    }
    
    if (minLevel !== undefined) {
      filteredItems = filteredItems.filter(item => item.level >= minLevel);
    }
    
    if (maxLevel !== undefined) {
      filteredItems = filteredItems.filter(item => item.level <= maxLevel);
    }
    
    if (currency) {
      filteredItems = filteredItems.filter(item => item.currency === currency);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      filteredItems = filteredItems.filter(item => 
        item.name.toLowerCase().includes(searchLower) || 
        item.description.toLowerCase().includes(searchLower)
      );
    }

    // Apply sorting
    switch (sortBy) {
      case "newest":
        filteredItems.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        break;
      case "price-low":
        filteredItems.sort((a, b) => {
          if (a.currency === "gold" && b.currency === "gold") {
            return (a.price || 0) - (b.price || 0);
          } else if (a.currency === "money" && b.currency === "money") {
            return parseFloat(a.realMoneyPrice || "0") - parseFloat(b.realMoneyPrice || "0");
          } else {
            return a.currency === "gold" ? -1 : 1;
          }
        });
        break;
      case "price-high":
        filteredItems.sort((a, b) => {
          if (a.currency === "gold" && b.currency === "gold") {
            return (b.price || 0) - (a.price || 0);
          } else if (a.currency === "money" && b.currency === "money") {
            return parseFloat(b.realMoneyPrice || "0") - parseFloat(a.realMoneyPrice || "0");
          } else {
            return a.currency === "money" ? -1 : 1;
          }
        });
        break;
      case "level":
        filteredItems.sort((a, b) => b.level - a.level);
        break;
    }

    // Calculate pagination
    const total = filteredItems.length;
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const paginatedItems = filteredItems.slice(startIndex, endIndex);

    return { items: paginatedItems, total };
  }

  async getUserItems(userId: number): Promise<Item[]> {
    return Array.from(this.items.values()).filter(
      (item) => item.sellerId === userId
    );
  }

  async updateItem(id: number, itemData: Partial<Item>): Promise<Item | undefined> {
    const existingItem = this.items.get(id);
    if (!existingItem) return undefined;
    
    const updatedItem = { ...existingItem, ...itemData };
    this.items.set(id, updatedItem);
    return updatedItem;
  }

  async deleteItem(id: number): Promise<boolean> {
    return this.items.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByBattlenetId(battlenetId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.battlenetId, battlenetId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Ensure we're setting all required fields
    const userData = {
      ...insertUser,
      createdAt: new Date(), // Set the creation date
    };
    
    console.log("Creating user with data:", userData);
    
    try {
      const [user] = await db.insert(users).values(userData).returning();
      console.log("User created successfully:", user);
      return user;
    } catch (error) {
      console.error("Error inserting user into database:", error);
      throw error;
    }
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async createItem(insertItem: InsertItem): Promise<Item> {
    // Ensure we're setting all required fields
    const itemData = {
      ...insertItem,
      createdAt: new Date(),
      sold: false, // Set initial sold status
    };
    
    console.log("Creating item with data:", itemData);
    
    try {
      const [item] = await db.insert(items).values(itemData).returning();
      console.log("Item created successfully:", item);
      return item;
    } catch (error) {
      console.error("Error inserting item into database:", error);
      throw error;
    }
  }

  async getItem(id: number): Promise<Item | undefined> {
    const [item] = await db.select().from(items).where(eq(items.id, id));
    return item;
  }

  async getAllItems(filters: {
    type?: string;
    rarity?: string;
    minLevel?: number;
    maxLevel?: number;
    currency?: string;
    search?: string;
    sortBy?: string;
    page?: number;
    pageSize?: number;
  } = {}): Promise<{ items: Item[], total: number }> {
    const {
      type,
      rarity,
      minLevel,
      maxLevel,
      currency,
      search,
      sortBy = "newest",
      page = 1,
      pageSize = 12
    } = filters;

    let query = db.select().from(items);
    let conditions = [];

    // Build filter conditions
    if (type) {
      conditions.push(eq(items.type, type));
    }
    
    if (rarity) {
      conditions.push(eq(items.rarity, rarity));
    }
    
    if (minLevel !== undefined) {
      conditions.push(gte(items.level, minLevel));
    }
    
    if (maxLevel !== undefined) {
      conditions.push(lte(items.level, maxLevel));
    }
    
    if (currency) {
      conditions.push(eq(items.currency, currency));
    }
    
    if (search) {
      conditions.push(like(items.name, `%${search}%`));
    }

    // Apply all conditions if any exist
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    // Apply sorting
    switch (sortBy) {
      case "newest":
        query = query.orderBy(desc(items.createdAt));
        break;
      case "price-low":
        if (currency === "gold") {
          query = query.orderBy(asc(items.price));
        } else if (currency === "money") {
          // This is a simple approximation - sorting text requires more complex handling
          query = query.orderBy(asc(items.realMoneyPrice));
        }
        break;
      case "price-high":
        if (currency === "gold") {
          query = query.orderBy(desc(items.price));
        } else if (currency === "money") {
          query = query.orderBy(desc(items.realMoneyPrice));
        }
        break;
      case "level":
        query = query.orderBy(desc(items.level));
        break;
    }

    // Get total count with the same filters
    const [{ value: total }] = await db
      .select({ value: count() })
      .from(items)
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    // Apply pagination
    query = query.limit(pageSize).offset((page - 1) * pageSize);

    const fetchedItems = await query;
    return { items: fetchedItems, total: Number(total) };
  }

  async getUserItems(userId: number): Promise<Item[]> {
    return db.select().from(items).where(eq(items.sellerId, userId));
  }

  async updateItem(id: number, itemData: Partial<Item>): Promise<Item | undefined> {
    const [updatedItem] = await db
      .update(items)
      .set(itemData)
      .where(eq(items.id, id))
      .returning();
    return updatedItem;
  }

  async deleteItem(id: number): Promise<boolean> {
    const result = await db.delete(items).where(eq(items.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Chat methods implementation
  async createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    try {
      const [newConversation] = await db
        .insert(chatConversations)
        .values({
          ...conversation,
          createdAt: new Date(),
          updatedAt: new Date(),
          battletagShared: false,
        })
        .returning();
      return newConversation;
    } catch (error) {
      console.error("Error creating chat conversation:", error);
      throw error;
    }
  }

  async getChatConversation(id: number): Promise<ChatConversation | undefined> {
    const [conversation] = await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, id));
    return conversation;
  }

  async getUserConversations(userId: number): Promise<ChatConversation[]> {
    return db
      .select()
      .from(chatConversations)
      .where(
        or(
          eq(chatConversations.buyerId, userId),
          eq(chatConversations.sellerId, userId)
        )
      )
      .orderBy(desc(chatConversations.updatedAt));
  }

  async getChatMessages(conversationId: number): Promise<ChatMessage[]> {
    return db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(asc(chatMessages.createdAt));
  }

  async addChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    try {
      const [newMessage] = await db
        .insert(chatMessages)
        .values({
          ...message,
          createdAt: new Date(),
        })
        .returning();
      
      // Update the conversation's updatedAt timestamp
      await db
        .update(chatConversations)
        .set({ updatedAt: new Date() })
        .where(eq(chatConversations.id, message.conversationId));
      
      return newMessage;
    } catch (error) {
      console.error("Error adding chat message:", error);
      throw error;
    }
  }

  async markConversationMessagesAsRead(conversationId: number, userId: number): Promise<void> {
    const now = new Date();
    await db
      .update(chatMessages)
      .set({ readAt: now })
      .where(
        and(
          eq(chatMessages.conversationId, conversationId),
          ne(chatMessages.senderId, userId),
          isNull(chatMessages.readAt)
        )
      );
  }

  async updateChatConversation(id: number, data: Partial<ChatConversation>): Promise<ChatConversation | undefined> {
    const [updatedConversation] = await db
      .update(chatConversations)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(chatConversations.id, id))
      .returning();
    return updatedConversation;
  }

  async getItemConversation(itemId: number, buyerId: number): Promise<ChatConversation | undefined> {
    // First, get the item to find out the seller
    const [item] = await db.select().from(items).where(eq(items.id, itemId));
    
    if (!item) {
      return undefined;
    }
    
    // Check if a conversation already exists for this item and buyer
    const [existingConversation] = await db
      .select()
      .from(chatConversations)
      .where(
        and(
          eq(chatConversations.itemId, itemId),
          eq(chatConversations.buyerId, buyerId)
        )
      );
    
    if (existingConversation) {
      return existingConversation;
    }
    
    // Create a new conversation
    const [newConversation] = await db
      .insert(chatConversations)
      .values({
        itemId: item.id,
        buyerId: buyerId,
        sellerId: item.sellerId,
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date(),
        battletagShared: false,
      })
      .returning();
    
    return newConversation;
  }

  async shareBattletag(conversationId: number): Promise<ChatConversation> {
    const [updatedConversation] = await db
      .update(chatConversations)
      .set({
        battletagShared: true,
        updatedAt: new Date(),
      })
      .where(eq(chatConversations.id, conversationId))
      .returning();
    
    if (!updatedConversation) {
      throw new Error("Conversation not found");
    }
    
    return updatedConversation;
  }
}

// Update the storage implementation to use the database
export const storage = new DatabaseStorage();
