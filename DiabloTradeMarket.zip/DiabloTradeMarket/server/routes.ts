import type { Express, Request, Response, NextFunction } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertItemSchema, 
  itemRarityEnum, 
  itemTypeEnum, 
  currencyEnum 
} from "@shared/schema";
import multer from "multer";
import path from "path";
import { randomUUID } from "crypto";
import fs from "fs";
import axios from "axios";
import session from "express-session";
import MemoryStore from "memorystore";
import { WebSocketServer } from "ws";
import WebSocket from "ws";
import { EventEmitter } from 'events';

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage2 = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${randomUUID()}`;
    cb(null, `${uniqueSuffix}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage: storage2,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG and GIF are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  const SessionStore = MemoryStore(session);
  app.use(
    session({
      store: new SessionStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      secret: process.env.SESSION_SECRET || "diablo-iv-trade-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Serve uploaded files
  app.use("/uploads", express.static(uploadDir));

  // Auth middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Debug route to check environment variables
  app.get("/api/auth/debug", (req, res) => {
    res.json({
      clientId: process.env.BATTLENET_CLIENT_ID ? "Set" : "Not set",
      clientSecret: process.env.BATTLENET_CLIENT_SECRET ? "Set" : "Not set",
      host: req.get("host"),
      protocol: req.protocol,
      env: process.env.NODE_ENV || "development"
    });
  });

  // Battle.net OAuth endpoints
  app.get("/api/auth/battlenet", (req, res) => {
    const clientId = process.env.BATTLENET_CLIENT_ID;
    if (!clientId) {
      return res.status(500).json({ message: "Battle.net client ID not configured" });
    }

    // Make sure the protocol is correct even behind proxy
    const protocol = req.headers['x-forwarded-proto'] ? req.headers['x-forwarded-proto'] : req.protocol;
    const host = req.get("host");
    
    // Build the redirect URI
    const redirectUri = `${protocol}://${host}/api/auth/battlenet/callback`;
    console.log("Generated redirect URI:", redirectUri);
    
    const authUrl = `https://oauth.battle.net/authorize?client_id=${clientId}&scope=openid&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}`;
    
    res.json({ authUrl });
  });

  app.get("/api/auth/battlenet/callback", async (req, res) => {
    console.log("Received callback from Battle.net, query params:", req.query);
    const { code } = req.query;
    
    if (!code) {
      console.error("Authorization code is missing in callback");
      return res.status(400).json({ message: "Authorization code is missing" });
    }

    const clientId = process.env.BATTLENET_CLIENT_ID;
    const clientSecret = process.env.BATTLENET_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      console.error("Battle.net credentials not configured");
      return res.status(500).json({ message: "Battle.net credentials not configured" });
    }

    // Make sure the callback URL matches exactly what was registered with Battle.net
    // Use forwarded protocol if available (for Replit proxy)
    const protocol = req.headers['x-forwarded-proto'] ? req.headers['x-forwarded-proto'] : req.protocol;
    const host = req.get("host");
    const redirectUri = `${protocol}://${host}/api/auth/battlenet/callback`;
    console.log("Using redirect URI:", redirectUri);

    try {
      console.log("Exchanging code for token...");
      // Exchange code for token
      const tokenResponse = await axios.post(
        "https://oauth.battle.net/token",
        new URLSearchParams({
          grant_type: "authorization_code",
          code: code as string,
          redirect_uri: redirectUri,
        }).toString(),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          auth: {
            username: clientId,
            password: clientSecret,
          },
        }
      );

      console.log("Token response received");
      const { access_token } = tokenResponse.data;

      // Get user info
      console.log("Fetching user info...");
      const userInfoResponse = await axios.get("https://oauth.battle.net/userinfo", {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
      });

      const userInfo = userInfoResponse.data;
      console.log("User info received:", JSON.stringify(userInfo, null, 2));

      // Find or create user
      console.log("Looking up user by Battle.net ID:", userInfo.sub);
      let user = await storage.getUserByBattlenetId(userInfo.sub);

      if (!user) {
        console.log("User not found, creating new user");
        // Create a new user with sanitized username
        const username = userInfo.battletag.replace(/[^a-zA-Z0-9-_]/g, "-");
        
        try {
          user = await storage.createUser({
            username: username,
            password: randomUUID(), // Random password since we're using OAuth
            battletag: userInfo.battletag,
            battlenetId: userInfo.sub,
            avatar: userInfo.picture || null,
            gold: 1000000 // Start with some gold
          });
          console.log("User created successfully:", user.id);
        } catch (createError) {
          console.error("Error creating user:", createError);
          throw createError;
        }
      } else {
        console.log("Existing user found:", user.id);
      }

      // Set user in session
      req.session.user = {
        id: user.id,
        username: user.username,
        battletag: user.battletag,
        avatar: user.avatar || undefined, // Convert null to undefined
        gold: user.gold || undefined, // Convert null to undefined
      };
      console.log("Session user set:", req.session.user);

      // Redirect to frontend
      console.log("Redirecting to frontend");
      res.redirect("/");
    } catch (error: any) {
      console.error("Battle.net OAuth error:", error);
      if (error.response) {
        console.error("Response data:", error.response.data);
        console.error("Response status:", error.response.status);
        console.error("Response headers:", error.response.headers);
      }
      res.status(500).json({ message: "Authentication failed", error: error.message });
    }
  });

  app.get("/api/auth/user", (req, res) => {
    if (req.session.user) {
      return res.json(req.session.user);
    }
    res.status(401).json({ message: "Not authenticated" });
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  // Items API
  app.get("/api/items", async (req, res) => {
    try {
      const { 
        type, 
        rarity, 
        minLevel, 
        maxLevel, 
        currency, 
        search, 
        sortBy, 
        page, 
        pageSize 
      } = req.query;

      const filters = {
        type: type as string | undefined,
        rarity: rarity as string | undefined,
        minLevel: minLevel ? parseInt(minLevel as string) : undefined,
        maxLevel: maxLevel ? parseInt(maxLevel as string) : undefined,
        currency: currency as string | undefined,
        search: search as string | undefined,
        sortBy: sortBy as string | undefined,
        page: page ? parseInt(page as string) : 1,
        pageSize: pageSize ? parseInt(pageSize as string) : 12
      };

      const { items, total } = await storage.getAllItems(filters);
      
      res.json({
        items,
        pagination: {
          total,
          page: filters.page,
          pageSize: filters.pageSize,
          totalPages: Math.ceil(total / filters.pageSize)
        }
      });
    } catch (error) {
      console.error("Error fetching items:", error);
      res.status(500).json({ message: "Failed to fetch items" });
    }
  });

  app.get("/api/items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }

      const item = await storage.getItem(id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      res.json(item);
    } catch (error) {
      console.error("Error fetching item:", error);
      res.status(500).json({ message: "Failed to fetch item" });
    }
  });

  app.get("/api/user/items", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const items = await storage.getUserItems(userId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching user items:", error);
      res.status(500).json({ message: "Failed to fetch your items" });
    }
  });

  app.post("/api/items", requireAuth, upload.single("image"), async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const itemData = JSON.parse(req.body.data);
      
      // Validate item data
      const parsedItemData = insertItemSchema.parse({
        ...itemData,
        sellerId: userId,
        image: req.file ? `/uploads/${req.file.filename}` : undefined
      });
      
      const newItem = await storage.createItem(parsedItemData);
      res.status(201).json(newItem);
    } catch (error: any) {
      console.error("Error creating item:", error);
      res.status(400).json({ message: error.message || "Failed to create item" });
    }
  });

  app.put("/api/items/:id", requireAuth, upload.single("image"), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }

      const userId = req.session.user!.id;
      const item = await storage.getItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      if (item.sellerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to update this item" });
      }

      const itemData = JSON.parse(req.body.data);
      
      // Keep the original image if no new one is uploaded
      const updatedItem = await storage.updateItem(id, {
        ...itemData,
        image: req.file ? `/uploads/${req.file.filename}` : item.image
      });
      
      res.json(updatedItem);
    } catch (error: any) {
      console.error("Error updating item:", error);
      res.status(400).json({ message: error.message || "Failed to update item" });
    }
  });

  app.delete("/api/items/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }

      const userId = req.session.user!.id;
      const item = await storage.getItem(id);
      
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      if (item.sellerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to delete this item" });
      }

      await storage.deleteItem(id);
      
      // Delete image file if it exists
      if (item.image && item.image.startsWith("/uploads/")) {
        const imagePath = path.join(process.cwd(), item.image);
        if (fs.existsSync(imagePath)) {
          fs.unlinkSync(imagePath);
        }
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting item:", error);
      res.status(500).json({ message: "Failed to delete item" });
    }
  });

  // Helper API endpoints
  app.get("/api/enum/rarities", (req, res) => {
    res.json(itemRarityEnum.options);
  });

  app.get("/api/enum/types", (req, res) => {
    res.json(itemTypeEnum.options);
  });

  app.get("/api/enum/currencies", (req, res) => {
    res.json(currencyEnum.options);
  });

  // Chat API endpoints
  
  // Get user conversations
  app.get("/api/conversations", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const conversations = await storage.getUserConversations(userId);
      
      // Fetch items and user info for each conversation
      const conversationsWithDetails = await Promise.all(
        conversations.map(async (conv) => {
          const item = await storage.getItem(conv.itemId);
          const buyer = await storage.getUser(conv.buyerId);
          const seller = await storage.getUser(conv.sellerId);
          
          // Count unread messages
          const messages = await storage.getChatMessages(conv.id);
          const unreadCount = messages.filter(
            msg => msg.senderId !== userId && !msg.readAt
          ).length;
          
          return {
            ...conv,
            item,
            buyer: {
              id: buyer?.id,
              username: buyer?.username,
              battletag: conv.battletagShared ? buyer?.battletag : undefined,
              avatar: buyer?.avatar,
            },
            seller: {
              id: seller?.id,
              username: seller?.username,
              battletag: conv.battletagShared ? seller?.battletag : undefined,
              avatar: seller?.avatar,
            },
            unreadCount,
          };
        })
      );
      
      res.json(conversationsWithDetails);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });
  
  // Get a specific conversation
  app.get("/api/conversations/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const conversationId = parseInt(req.params.id);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getChatConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Check if user is part of the conversation
      if (conversation.buyerId !== userId && conversation.sellerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to access this conversation" });
      }
      
      // Mark messages as read
      await storage.markConversationMessagesAsRead(conversationId, userId);
      
      // Fetch item and user info
      const item = await storage.getItem(conversation.itemId);
      const buyer = await storage.getUser(conversation.buyerId);
      const seller = await storage.getUser(conversation.sellerId);
      
      // Fetch messages
      const messages = await storage.getChatMessages(conversationId);
      
      const response = {
        ...conversation,
        item,
        buyer: {
          id: buyer?.id,
          username: buyer?.username,
          battletag: conversation.battletagShared ? buyer?.battletag : undefined,
          avatar: buyer?.avatar,
        },
        seller: {
          id: seller?.id,
          username: seller?.username,
          battletag: conversation.battletagShared ? seller?.battletag : undefined,
          avatar: seller?.avatar,
        },
        messages,
      };
      
      res.json(response);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });
  
  // Create or get an existing conversation
  app.post("/api/items/:id/conversation", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const itemId = parseInt(req.params.id);
      
      if (isNaN(itemId)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      // Get the item
      const item = await storage.getItem(itemId);
      
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      // Check if the user is not the seller
      if (item.sellerId === userId) {
        return res.status(400).json({ message: "You cannot start a conversation about your own item" });
      }
      
      // Get or create a conversation
      const conversation = await storage.getItemConversation(itemId, userId);
      
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });
  
  // Add a message to a conversation
  app.post("/api/conversations/:id/messages", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const conversationId = parseInt(req.params.id);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getChatConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Check if user is part of the conversation
      if (conversation.buyerId !== userId && conversation.sellerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to send messages in this conversation" });
      }
      
      const { content } = req.body;
      
      if (!content || typeof content !== "string" || content.trim() === "") {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Add the message
      const message = await storage.addChatMessage({
        conversationId,
        senderId: userId,
        content: content.trim(),
      });
      
      res.status(201).json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  // Share battletag in a conversation
  app.post("/api/conversations/:id/share-battletag", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const conversationId = parseInt(req.params.id);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getChatConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Check if user is part of the conversation
      if (conversation.buyerId !== userId && conversation.sellerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to access this conversation" });
      }
      
      // Share battletag
      const updatedConversation = await storage.shareBattletag(conversationId);
      
      // Add a system message about battletag being shared
      await storage.addChatMessage({
        conversationId,
        senderId: userId,
        content: "Battletags have been shared. You can now add each other in-game to complete the transaction.",
      });
      
      res.json(updatedConversation);
    } catch (error) {
      console.error("Error sharing battletag:", error);
      res.status(500).json({ message: "Failed to share battletag" });
    }
  });

  const httpServer = createServer(app);
  
  // Create a custom event emitter for chat messages
  const chatEvents = new EventEmitter();
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Extend WebSocket interface to include conversationId
  interface ChatWebSocket extends WebSocket {
    conversationId?: number;
  }
  
  wss.on('connection', (ws: ChatWebSocket) => {
    console.log('WebSocket client connected');
    
    ws.on('message', async (message: WebSocket.Data) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        if (data.type === 'join_conversation') {
          // Allow joining specific conversation room
          ws.conversationId = data.conversationId;
          console.log(`Client joined conversation ${data.conversationId}`);
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });
  
  // Use the event emitter to broadcast messages
  chatEvents.on('new_message', (conversationId: number, message: any) => {
    wss.clients.forEach((client: WebSocket) => {
      const chatClient = client as ChatWebSocket;
      if (
        chatClient.conversationId === conversationId && 
        chatClient.readyState === WebSocket.OPEN
      ) {
        chatClient.send(JSON.stringify({
          type: 'new_message',
          message
        }));
      }
    });
  });
  
  // When a new message is added, emit an event
  app.post("/api/conversations/:id/messages", requireAuth, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const conversationId = parseInt(req.params.id);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      const conversation = await storage.getChatConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      // Check if user is part of the conversation
      if (conversation.buyerId !== userId && conversation.sellerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to send messages in this conversation" });
      }
      
      const { content } = req.body;
      
      if (!content || typeof content !== "string" || content.trim() === "") {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      // Add the message
      const message = await storage.addChatMessage({
        conversationId,
        senderId: userId,
        content: content.trim(),
      });
      
      // Get user info for the message
      const sender = await storage.getUser(userId);
      
      // Emit event to notify connected clients
      chatEvents.emit('new_message', conversationId, {
        ...message,
        sender: {
          id: sender?.id,
          username: sender?.username,
          avatar: sender?.avatar,
        }
      });
      
      res.status(201).json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  return httpServer;
}
