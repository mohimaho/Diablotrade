import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.diabloivtrade.app',
  appName: 'Diablo IV Trade',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true
  },
  android: {
    // Android-specific configuration 
  },
  plugins: {
    // Minimum SDK version for Android
    CapacitorHttp: {
      enabled: true
    }
  }
};

export default config;